package com.training.models;

public class BirthDay {

	private int age;
	private int dateofbirth;
	private String month;
	private int year;
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public int getDateofbirth() {
		return dateofbirth;
	}
	public void setDateofbirth(int dateofbirth) {
		this.dateofbirth = dateofbirth;
	}
	public String getMonth() {
		return month;
	}
	public void setMonth(String month) {
		this.month = month;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public BirthDay(int age, int dateofbirth, String month, int year) {
		super();
		this.age = age;
		this.dateofbirth = dateofbirth;
		this.month = month;
		this.year = year;
	}
	public BirthDay() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "BirthDay [age=" + age + ", dateofbirth=" + dateofbirth + ", month=" + month + ", year=" + year + "]";
	}
	
	
}
