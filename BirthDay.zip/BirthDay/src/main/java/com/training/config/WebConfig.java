package com.training.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.view.InternalResourceViewResolver;
import org.springframework.web.servlet.view.JstlView;

import com.training.models.BirthDay;

@Configuration
@EnableWebMvc
@ComponentScan(basePackages="com.training.controllers")
public class WebConfig implements WebMvcConfigurer {
	@Bean
	
	public InternalResourceViewResolver resolver() {
	 InternalResourceViewResolver resolver=new InternalResourceViewResolver();
	 
	 
	 resolver.setPrefix("/WEB-INF/views/");
	 resolver.setSuffix(".jsp");
	 resolver.setViewClass(JstlView.class);
	 return resolver;
	 
		
	}
	
	@Bean
	public ModelAndView mdlview()
	{
		return new ModelAndView();
	}
	@Bean
	public BirthDay birthday()
	{
		return new BirthDay();	
		}

}
