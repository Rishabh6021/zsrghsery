package com.training.controllers;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.training.models.BirthDay;


@Controller

public class WelcomeController {

	@Autowired
	private BirthDay birthday;
	@Autowired
	private ModelAndView mdlview;	
	
	@GetMapping("/birthday")
	public ModelAndView initForm()
	
	{
		mdlview.setViewName("index");
		mdlview.addObject("command",birthday);
		return mdlview;
	}
	@PostMapping("/birthday")
	public String  onSubmit( @ModelAttribute("data")BirthDay birthday,Model model)
	{
		
		int age=birthday.getYear();
		
		int currentyear=2019;
		
		int currentage=currentyear-age;
		model.addAttribute("currentage", currentage);
		
		String nextPage="Success";
		
		
		return nextPage;
		
	}
}
